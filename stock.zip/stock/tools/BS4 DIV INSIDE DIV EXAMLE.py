import requests

from bs4 import BeautifulSoup
# from find import *

import requests
from bs4 import BeautifulSoup

def make_soup(url):
    try:
        html = requests.get(url, headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.80 Safari/537.36"}).content
        print("succes")
    except:
        print("not done")
        return None
    return BeautifulSoup(html, "lxml")

# def check(stock):
#     url="https://money.rediff.com/companies/"+stock 
#     soup = make_soup(url)
#     f = open("req_code.txt", "w")
#     text = str(soup.prettify().encode('cp1252', errors='ignore'))
#     f.write(text)
#     f.close()
#     key = "ltpid"
#     arr = findall_like(key, text)
#     arr=(arr[0])
#     price =text[arr:arr+119]
#     price =price.split("\\n")
#     price=price[1]
#     price= (price.strip())
#     return (price)
# stock="SUNTV"
# check(stock)
print("acessing...")
URL = 'https://www1.nseindia.com/live_market/dynaContent/live_watch/live_index_watch.htm'
# page = requests.get(URL)
soup = make_soup(URL)

print('\nrequest done\n\n')

# soup = BeautifulSoup(page.content, 'html.parser')
# f = open("code.txt", "w")
# sfile = str(soup.prettify().encode('cp1252', errors='ignore'))
# f.write(sfile)
# f.close()
# print('soup done\n\n')
# for foo in soup.find_all('div', attrs={'class': 'w-dyn-item w-col w-col-4'}):
#     foo_descendants = foo.descendants
#     div = True
#     for d in foo_descendants:
#         if (div):
#             if d.name == 'div' and d.get('class', '') == ['product__price']:
#                 print(d.text)
#                 div = False
#         if d.name == 'a' and d.get('class', '') == ['product__name']:
#             print(d.text)
#             div = True

#             pass


# -----------------------------------------------------------------------------------------------------

# for foo in soup.find_all('div', attrs={'class': 'ww-dyn-items w-row'}):
#     bar = foo.find('div', attrs={'class': 'w-dyn-item w-col w-col-4'})
#     print(bar)

# seven_day = soup.find(id="seven-day-forecast")
# forecast_items = soup.find('div',class_="w-dyn-items w-row")
# products = forecast_items.find('div',class_="w-dyn-item w-col w-col-4").prettify()
# price = item.find('div',class_="product__price").text
# print(products)
# f = open("code.txt", "w")
# sfile = str( forecast_items)
# f.write(sfile )
# f.close()

# print(forecast_items)
# for item in forecast_items:
#     print(item)
# soup.find("div", {"id": "articlebody"})
# name="card-job-description"

# f = open("code.txt", "w")
# sfile = str( forecast_items.prettify().encode('cp1252', errors='ignore'))
# f.write(sfile )
# f.close()