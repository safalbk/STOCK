# https://stackoverflow.com/questions/63981362/python-requests-get-returns-response-code-401-for-nse-india-website
import requests
# URL = 'https://www1.nseindia.com/live_market/dynaContent/live_watch/live_index_watch.htm'
baseurl = "https://www1.nseindia.com/"
url = f"https://www1.nseindia.com/live_market/dynaContent/live_watch/live_index_watch.htm"
headers = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, '
                         'like Gecko) '
                         'Chrome/80.0.3987.149 Safari/537.36',
           'accept-language': 'en,gu;q=0.9,hi;q=0.8', 'accept-encoding': 'gzip, deflate, br'}
session = requests.Session()
request = session.get(baseurl, headers=headers, timeout=5)
cookies = dict(request.cookies)
response = session.get(url, headers=headers, timeout=5, cookies=cookies)
html =response.content

print(session)
f = open("req_code.txt", "w")
text = str(html)
f.write(text)
f.close()