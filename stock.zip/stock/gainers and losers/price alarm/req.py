from find import *

import requests
from bs4 import BeautifulSoup

def make_soup(url):
    try:
        html = requests.get(url, headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.80 Safari/537.36"}).content
    except:
        return None
    return BeautifulSoup(html, "lxml")

def check(stock):
    url="https://money.rediff.com/companies/"+stock 
    soup = make_soup(url)
    f = open("req_code.txt", "w")
    text = str(soup.prettify().encode('cp1252', errors='ignore'))
    f.write(text)
    f.close()
    key = "ltpid"
    arr = findall_like(key, text)
    arr=(arr[0])
    price =text[arr:arr+119]
    price =price.split("\\n")
    price=price[1]
    price= (price.strip())
    return (price)
stock="SUNTV"
check(stock)

