import pyttsx3
from find import *
from req import *

engine = pyttsx3.init()
engine.setProperty('rate', 110)
def speak(text):
    engine.say(text)
    engine.runAndWait()

def gtprice(price,val):
    if(val<=float(price)):
        return True
    else:
        return False

def ltprice(price,val):
    if(val>=float(price)):
        return True
    else:
        return False

# stock="TATAMOTORS"
def alarm(stock,price,condition,value,message):
    if(condition=="gt"):
        if(gtprice(price,value)):
            print(stock+" current price is "+price)
            speak(message)
            speak(message)
    if(condition=="lt"):
        if(ltprice(price,value)):
            print(stock+" current price is "+price)
            speak(message)
            speak(message)

while(True):
    # stock="tata motors"
    # price =check(stock)
    # print(stock+" price is "+price)
    # condition="gt"
    # value=390.00
    # message="breakout at "+stock+" buy side"
    # alarm(stock,price,condition,value,message)

    # stock="tata motors"
    # price =check(stock)
    # print(stock+" price is "+price)
    # condition="lt"
    # value=379.00
    # message="breakout at "+stock+" sell side"
    # alarm(stock,price,condition,value,message)

    
    stock="LIC Housing Finance Ltd"
    price =check(stock)
    print(stock+" price is "+price)
    condition="gt"
    value=453.00
    message="breakout at "+stock+" buy side"
    alarm(stock,price,condition,value,message)

    stock="LIC Housing Finance Ltd"
    price =check(stock)
    print(stock+" price is "+price)
    condition="lt"
    value=440.00
    message="breakout at "+stock+" sell side"
    alarm(stock,price,condition,value,message)

    stock="igl"
    price =check(stock)
    print(stock+" price is "+price)
    condition="lt"
    value=515.00
    message="breakout at "+stock+" sell side"
    alarm(stock,price,condition,value,message)

    stock="Cadila Healthcare Ltd"
    price =check(stock)
    print(stock+" price is "+price)
    condition="gt"
    value=554.00
    message="breakout at "+stock+" buy side"
    alarm(stock,price,condition,value,message)

    stock="Cadila Healthcare Ltd"
    price =check(stock)
    print(stock+" price is "+price)
    condition="lt"
    value=548.00
    message="breakout at "+stock+" sell side"
    alarm(stock,price,condition,value,message)

    stock="BHARTIARTL "
    price =check(stock)
    print(stock+" price is "+price)
    condition="gt"
    value=703.00
    message="breakout at "+stock+" buy side"
    alarm(stock,price,condition,value,message)

    stock="BHARTIARTL "
    price =check(stock)
    print(stock+" price is "+price)
    condition="lt"
    value=688.00
    message="breakout at "+stock+" sell side"
    alarm(stock,price,condition,value,message)

    print("-------------------------------------------------")





# start = time.time()
# print("initializing....")
# stock="SUNTV"
# print("stock is ...."+stock)
# price =check(stock)
# if (gtprice(price,528.30)):
#     speak(stock+" current price is "+price)
#     print(stock+" current price is "+price)
# done = time.time()
# elapsed = done - start
# print("time taken....."+str(elapsed))


# start = time.time()
# print("initializing....")
# print("stock is ...."+stock)
# price =check(stock)
# speak(stock+" current price is "+price)
# print(stock+" current price is "+price)
# done = time.time()
# elapsed = done - start
# print("time taken....."+str(elapsed))
# a=input("enter to exit")
# rate = engine.getProperty('rate')   # getting details of current speaking rate
# print (rate)                        #printing current voice rate
     # setting up new voice rate