import time
from find import *
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import requests
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from fake_useragent import UserAgent



options = Options()
options.add_argument("window-size=1400,600")
user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'
options = webdriver.ChromeOptions()
options.add_experimental_option('excludeSwitches', ['enable-logging'])
options.add_argument(f'user-agent={user_agent}')
driver = webdriver.Chrome(executable_path="C:\drivers\chromedriver_win32\chromedriver.exe",options=options)
# driver.set_page_load_timeout(20)

def url(stock):
    # print("acessing site....")
    address="https://money.rediff.com/companies/"+stock 
    driver.get(address)
    time.sleep(1)
    driver.execute_script("window.stop();")
    # print("successfull....")
def check():
    # print("extracting ....")
    html= driver.page_source
    soup = BeautifulSoup(html, 'html.parser')
    f = open("code.txt", "w")
    sfile = str(soup.prettify().encode('cp1252', errors='ignore'))
    f.write(sfile)
    f.close()
    # print("soup done")


    f = open("code.txt", "r")
    text=f.read()
    key = """id="ltpid" """
    arr = findall_like(key, text)
    arr=(arr[0])
    price =text[arr:arr+119]
    price =price.split("\\n")
    price=price[1]
    price= (price.strip())
    return price
def destroy():
    driver.quit()
# -------------- main program-------------------------------------------------------------------------
# stock="SUNTV"
# url(stock)
# print(check())
# time.sleep(2)
# print("-------------------------")
# stock="TATAMOTORS"
# url(stock)
# time.sleep(0.5)
# print(check())
# print("-------------------------")
# stock="RELIANCE"
# url(stock)
# time.sleep(0.5)
# print(check())
# print("-------------------------")
# stock="WIPRO"
# url(stock)
# time.sleep(0.5)
# print(check())
# f = open("code.txt", "r")
# text=f.read()
# key = """id="ltpid" """
# arr = findall_like(key, text)
# arr=(arr[0])
# price =text[arr:arr+119]
# price =price.split("\\n")
# price=price[1]
# print(price.strip())
# time.sleep(10)
