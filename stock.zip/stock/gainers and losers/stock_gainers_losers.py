from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import requests
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import time
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from fake_useragent import UserAgent
from find import *
options = Options()
options.add_argument("window-size=1400,600")

user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'
options = webdriver.ChromeOptions()
options.add_experimental_option('excludeSwitches', ['enable-logging'])
options.add_argument(f'user-agent={user_agent}')
driver = webdriver.Chrome(executable_path="C:\drivers\chromedriver_win32\chromedriver.exe",options=options)
driver.get("https://www.nseindia.com/")
time.sleep(5)

def refersh():
    


    # user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36'

    # wait = WebDriverWait(driver, 20)

    # action = ActionChains(driver)
    # driver.implicitly_wait(5)


    html= driver.page_source

    soup = BeautifulSoup(html, 'html.parser')
    f = open("code.txt", "w")
    sfile = str(soup.prettify().encode('cp1252', errors='ignore'))
    f.write(sfile)
    f.close()
    print('soup done\n\n')


    f = open("code.txt", "r")
    text=f.read()
    key = "<script>"
    arr = findall_like(key, text)
    key = ',"ejsHelpers"'

    arr2 = findall_like(key, text)

    f = open("script.js", "w")
    fun =""" function myFunction() {
    //var symbol=window.headerData['indexDataInfo'] [0] ['data']['symbol'] ;
    
    var loserlen =window.headerData['indexDataInfo'] [0].topLosers.data;
    var gainerlen =window.headerData['indexDataInfo'] [0].topGainers.data;

    let text = '<p style="color:green;font-size: 20px;">Gainers</p><br>';
    for (let i = 0; i < gainerlen.length; i++) {
    var symbol=window.headerData['indexDataInfo'] [0].topGainers.data[i].symbol;
    var lastprice=window.headerData['indexDataInfo'] [0].topGainers.data[i].lastPrice;
    var pChange=window.headerData['indexDataInfo'] [0].topGainers.data[i].pChange;
    var result =symbol+' || '+String(lastprice)+' ||  '+pChange; 
    text += result + "<br>";
    }
    text +='<p style="color:red;font-size: 20px;">Loosers</p><br>';
    for (let i = 0; i < loserlen.length; i++) {
    var symbol=window.headerData['indexDataInfo'] [0].topLosers.data[i].symbol;
    var lastprice=window.headerData['indexDataInfo'] [0].topLosers.data[i].lastPrice;
    var pChange=window.headerData['indexDataInfo'] [0].topLosers.data[i].pChange;
    var result =symbol+' || '+String(lastprice)+' ||  '+pChange; 
    text += result + "<br>";
    }
    document.getElementById("demo").innerHTML = text;
    }
    function time() {
      alert("Hello! I am an alert box!");
    }
//    var delayInMilliseconds = 1000; //1 second

// setTimeout(function() {
//   alert("test");
// }, delayInMilliseconds);


    """
    sc = fun+(text[arr[1]+10:arr2[0]])+"}"
    f.write(sc)
    f.close()
while True:
    time.sleep(10)

    refersh()
    time.sleep(60)

