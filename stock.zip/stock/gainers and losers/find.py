import time
def findall_like(keyword="", text=""):
    bal=0
    x=[]
    value=0
    flag=True
    ctext = text
    #count!=len(text)
    #ctext!="" 
    while(flag):
        if(ctext.find(keyword)!=-1):
            value=(ctext.find(keyword))#add first key position
            if(ctext[:value]==""):
                bal=bal+len(ctext[:value])
            else:
                bal=bal+len(ctext[:value])
            x.append(bal)
            ctext=ctext[value+len(keyword)+1:]  
            bal=bal+(len(keyword)+1) 
            if(ctext.find(keyword)==-1):
                flag=False
    return x         

def findall(keyword="", text=""):
    i=0
    j=0
    ctext=text
    while(j<len(ctext)):
        while(keyword[i]==ctext[j]):
            i=i+1
            j=j+1
            if(len(keyword)-1==i):
                print("word found")
                break
        

    return i


# def findall(keyword="", text=""):
#     bal=0
#     x=[]
#     value=0
#     flag=True
#     ctext = text
#     print(text,"\n\n")
#     #count!=len(text)
#     #ctext!="" 
#     while(flag):
#         if(ctext.find(keyword)!=-1):

#             print(ctext)
#             value=(ctext.find(keyword))#add first key position
#             print("value= ",value)
#             if((ctext[value-1]==" ") or (ctext[:value]=="")):
#                 print("second phase")
#                 if(ctext[:value]==""):
#                     bal=bal+len(ctext[:value])
#                     print("bal ",bal)
#                 else:
#                     bal=bal+len(ctext[:value])
#                     print("bal ",bal)
#                 x.append(bal)
#                 ctext=ctext[value+len(keyword)+1:]  
#                 bal=bal+(len(keyword)+1) 
#                 print("bal ",bal)
#                 print(ctext)
#                 if(ctext.find(keyword)==-1):
#                     flag=False
#             else:
#                 i=0
#                 while(ctext[value+i]!=" "):
#                     i=i+1
#                     print(i)
#                 ctext=ctext[value+i+1:]   
#                 print(ctext)  
#         print('\n\n')
#         time.sleep(1)
#     return x    