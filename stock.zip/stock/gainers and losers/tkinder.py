# import everything from tkinter module
from tkinter import *
import time
# import messagebox from tkinter module
import tkinter.messagebox

# create a tkinter root window
root = tkinter.Tk()

# root window title and dimension
root.title("When you press a button the message will pop up")
window_height = 500
window_width = 900

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

x_cordinate = int((screen_width/2) - (window_width/2))
y_cordinate = int((screen_height/2) - (window_height/2))
print(x_cordinate," ",y_cordinate)
# Create a messagebox showinfo
root.geometry("{}x{}+{}+{}".format(window_width, window_height, x_cordinate, y_cordinate))

def onClick():
    time.sleep(3)
    tkinter.messagebox.showinfo("Welcome to GFG.", "Hi I'm your message")
    
    
   

# Create a Button
button = Button(root, text="Click Me", command=onClick, height=5, width=10)

# Set the position of button on the top of window.
button.pack(side='bottom')
root.mainloop()
# import tkinter as tk

# win = tk.Tk()  # Creating instance of Tk class
# win.title("Centering windows")
# win.resizable(False, False)  # This code helps to disable windows from resizing

# window_height = 500
# window_width = 900

# screen_width = win.winfo_screenwidth()
# screen_height = win.winfo_screenheight()

# x_cordinate = int((screen_width/2) - (window_width/2))
# y_cordinate = int((screen_height/2) - (window_height/2))

# win.geometry("{}x{}+{}+{}".format(window_width, window_height, x_cordinate, y_cordinate))

# win.mainloop()