from tkinter import *

def messagebox():
	toplevel = Toplevel(root)
	toplevel.title("QUIT")
	toplevel.geometry(f"300x100+{root.winfo_x()}+{root.winfo_y()}")

	l1=Label(toplevel, image="::tk::icons::question")
	l1.grid(row=0, column=0, pady=(7, 0), padx=(10, 30), sticky="e")
	l2=Label(toplevel,text="Are you sure you want to Quit")
	l2.grid(row=0, column=1, columnspan=3, pady=(7, 10), sticky="w")

	b1=Button(toplevel,text="Yes",command=root.destroy,width = 10)
	b1.grid(row=1, column=1, padx=(2, 35), sticky="e")
	b2=Button(toplevel,text="No",command=toplevel.destroy,width = 10)
	b2.grid(row=1, column=2, padx=(2, 35), sticky="e")


root = Tk()
# width height
root.geometry("300x130")
root.title("Main Window")
# Button(root,text="Quit",command=messagebox,width = 7).pack(pady=80)
button = Button(root, text="quit", command=messagebox, height=5, width=7)

# Set the position of button on the top of window.
button.pack(side='bottom')
root.mainloop()
