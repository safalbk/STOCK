capital =1200
lev=5
stock=800
a=(capital*lev)/stock
print("capital =",capital)
print("leverage =",lev)
print("stock price =",stock)
print("no of stocks can buy =",a)
while(True):
    print("----------------------------------")
    n=input("enter stock price to calcualte quantity ")
    if(n==""):
        continue
    b =(capital*lev)/int(n)
    print("no of stocks can buy =",b)
    print("")
    print("")
    print("")
    print("")